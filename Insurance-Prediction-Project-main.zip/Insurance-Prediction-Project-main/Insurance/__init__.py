from dotenv import load_dotenv
print(f"Loading env variable from .env")
load_dotenv()